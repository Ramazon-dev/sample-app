import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_app_getx/controller/main/home/assembly/assembly_controller.dart';
import 'package:sample_app_getx/core/theme/app_colors.dart';
import 'package:sample_app_getx/ui/main/home/assembly/widgets/product_color_item.dart';
import 'package:sample_app_getx/ui/main/home/assembly/widgets/text_widget.dart';

import 'widgets/product_memory_item.dart';
import 'widgets/product_sim_item.dart';

class AssemblyPage extends GetView<AssemblyController> {
  const AssemblyPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("assembly"),
      ),
      body: GetBuilder<AssemblyController>(
        builder: (logic) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const TextWidget(
                  text: 'Выберите цвет',
                ),
                const ProductColorItem(),
                const TextWidget(text: 'Выберите емкость памяти'),
                const ProductMemoryItem(),
                const TextWidget(text: 'Выберите конфигурацию'),
                const ProductSimItem(),
                const TextWidget(text: 'Характеристики'),
                Container(
                  height: 160,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Text('text about charecter of item'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
